import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {
  username:string='';
  password:string='';
  error:string='';
  
  constructor(private route :Router) { }

  ngOnInit(): void {
    localStorage.removeItem('user')
  }

  login(e:any){
    e.preventDefault();

    //Validate User Credentials against localStorage and Navigate to pages accordingly.

    if(this.username==='' || this.password===''){
      this.error="username and password can not be blank"
    }
    else{
      if(this.username==='admin' && this.password==='admin'){

        const user={
          username : this.username,
          token : '12345'
        }
        localStorage.setItem('user',JSON.stringify(user))
        this.route.navigate(['/todo'])
      }
      else{
        this.error="username and password does not match"
      }
    }
  }

  handleChange(){
    this.error='';
  }

}
