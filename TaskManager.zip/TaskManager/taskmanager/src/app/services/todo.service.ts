import { Injectable } from '@angular/core';
import {Task} from '../models/Task';
import {Observable} from 'rxjs/observable';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  url: string="http://localhost:3000/todos"
  tasks: Task[]=[];
  task:any;

  constructor( private http : HttpClient) { }

  //Fetch task activites from database with APIs.

  getAllTasks():Observable<Task[]>{
    return this.http.get<Task[]>(this.url)
  }


  // Add new activity to Task Manager

  addTask(task:string):Observable<Task>{
    let newTask:Task={
      id:this.tasks.length,
      name:task,
      completed : false,
      date:new Date()
    }
    return this.http.post<Task>(this.url,newTask)
  }

  removeTask(id:number):Observable<Task>{
    return this.http.delete<Task>(this.url+"/"+id);
  }


  getTaskDetails(task:Task){
    this.task=task
  }

  editTask(task:string,id:number):Observable<Task>{
    let newTask:Task={
      id:id,
      name:task,
      completed : false,
      date:new Date()
    }
    return this.http.put<Task>(this.url+"/"+id,newTask)

  }
}
