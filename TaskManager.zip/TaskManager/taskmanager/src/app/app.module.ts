import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {Router,RouterModule, Routes} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { TodoAppComponent } from './components/todo-app/todo-app.component';
import { TodoService } from './services/todo.service';
import { HighlightDirective } from './directives/highlight.directive';
import { CustomUppercasePipe } from './pipes/custom-uppercase.pipe';
import { SearchPipe } from './pipes/search.pipe';
import { RegFormComponent } from './components/reg-form/reg-form.component';
import { AuthGuard} from './auth.guard';
import { TodoDetailsComponent } from './components/todo-app/todo-details/todo-details.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';

const routes:Routes=[
{path:'',redirectTo:'/login',pathMatch:'full'},
{path:'login',component:LoginFormComponent},
{path:'register',component:RegFormComponent},
{path:'todo/:id',component:TodoDetailsComponent,canActivate:[AuthGuard]},
{path:'todo',component:TodoAppComponent,canActivate:[AuthGuard]},
{path:'**',component:PageNotFoundComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    LoginFormComponent,
    TodoAppComponent,
    HighlightDirective,
    CustomUppercasePipe,
    SearchPipe,
    RegFormComponent,
    TodoDetailsComponent,
    PageNotFoundComponent,    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [TodoService,
    AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
