import { Component, OnInit } from '@angular/core';
import { TodoService} from '../../services/todo.service';
import {Task} from '../../models/Task';


@Component({
  selector: 'app-todo-app',
  templateUrl: './todo-app.component.html',
  styleUrls: ['./todo-app.component.css']
})
export class TodoAppComponent implements OnInit {

  tasks :Task[]=[];
  task:string='';
  errorMsg:string='';
  successMsg:string='';
  editIndex:number=-1;
  query:string=''

  constructor(private todo: TodoService) { }

  ngOnInit(): void {
    // Get all task details upon successful login
    this.getAllTasks()
  }
  
  editTask(task:any){
    // Fetch task details for task to be modified
    this.task=task.name
    this.editIndex=task.id;
  }

  getAllTasks(){
    //Subscribe to observable to fetch all task details with the help of service
    this.todo.getAllTasks().subscribe(data=>{
      this.tasks=data;
    })
  }


  saveTask(e:any){
    e.preventDefault()

    // Save updated task details and fetch updated task details

    this.todo.editTask(this.task,this.editIndex).subscribe(data=>{
      this.successMsg='Task edited successfully'
    setTimeout(()=>this.successMsg='',3000)
    this.getAllTasks()
    this.editIndex=-1;
    this.task=''
    })
    
  }

  addTask(e:any){
    e.preventDefault()

    //Add new task to the Task Manager

    if(this.task===''){
      this.errorMsg='Task can not be blank'
    }
    else{
      this.todo.addTask(this.task).subscribe(
      data=>{
        this.successMsg='Task successfully submitted'
        this.task=''
        setTimeout(()=>this.successMsg='',3000)
        this.getAllTasks()
    },
      error=>{
        this.errorMsg='Task not added'
        this.task=''
        setTimeout(()=>this.successMsg='',3000)
      }
      )
      
    }
  }

  handleChange(e:any){
    if(e.keyCode!==13){
      this.errorMsg=''
      this.successMsg=''
    }
    
  }

  removeTask(id:number){

    //Delete the task completed and fetch updated task details

    let ConfirmedTask=confirm('Are you sure ?')
    if(ConfirmedTask){
        this.todo.removeTask(id).subscribe(()=>{
        this.successMsg="Task removed successfully"
        setTimeout(()=>this.successMsg='',3000)
        this.getAllTasks()
      })
      

    }
        
  }
}
