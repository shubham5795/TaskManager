import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {Task} from '../../../models/Task';
import {TodoService} from '../../../services/todo.service'

@Component({
  selector: 'app-todo-details',
  templateUrl: './todo-details.component.html',
  styleUrls: ['./todo-details.component.css']
})
export class TodoDetailsComponent implements OnInit {

  task :Task ;
  constructor( private route : ActivatedRoute,
    private todo : TodoService) { }

  ngOnInit(): void {
    // Get single task activity from service
    this.task=this.todo.task;
  }

}
