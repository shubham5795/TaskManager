import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reg-form',
  templateUrl: './reg-form.component.html',
  styleUrls: ['./reg-form.component.css']
})
export class RegFormComponent implements OnInit {
  categories:string[]=[
    "Education",
    "Student",
    "Qualification"
  ];
  model:any={}
  constructor() { }

  ngOnInit(): void {
  }
  register(){
    //Store form values in database
    console.log(this.model)
  }

}
