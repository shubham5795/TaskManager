import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(value: any, ...args: any): any {

    // Filter the task activities against task name

    let filterItems=value.filter( el => {
      if(el.name.search(args)> -1){
        return true
      }
      else{
        return false
      }
    })
    return filterItems
  }

}
